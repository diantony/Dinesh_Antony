/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Patient;

import Business.MedicalId.MedicalRecord;
import Business.Person;
import Business.UserAccount.UserAccount;
import com.db4o.User;

/**
 *
 * @author Niranjanii
 */
public class Patient extends Person{
    
   private MedicalRecord medicalRecord;
   private UserAccount userAccount;
   
   
   public Patient()
   {
       userAccount = new UserAccount();
   }

    public UserAccount getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(UserAccount userAccount) {
        this.userAccount = userAccount;
    }
   

    public MedicalRecord getMedicalRecord() {
        return medicalRecord;
    }

    public void setMedicalRecord(MedicalRecord medicalRecord) {
        this.medicalRecord = medicalRecord;
    }


}
