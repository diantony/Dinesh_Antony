package com.me.project.model;

import org.springframework.transaction.annotation.Transactional;

@Transactional
public class CartEntryDTO {

    private Integer entry_Id;

    private Product product;

    private Cart cart;

    private Integer quantity;

    public Integer getEntryId() {
        return entry_Id;
    }

    public void setEntryId(Integer entryId) {
        this.entry_Id = entryId;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}
