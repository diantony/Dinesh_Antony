package com.me.project.interfaces;

import com.me.project.model.users.User;
import com.me.project.model.users.UserDto;

public interface IUserService {

    void registerNewUserAccount(UserDto accountDto);

    boolean login(User user);

    void addUser(User user);

    void activatingUserAccount(Integer id);
}