package com.me.project.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GenerationType;
import javax.persistence.Column;

@Entity
@Table(name = "medicine")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "medid")
    private int medId;
    @Column
    private String name;
    @Column
    private String brand;
    @Column
    private Double price;
    @Column
    private Integer stock;
    @Column(name = "type")
    private String medType;
    @Column
    private String countryOfOrigin;
    @Column
    private Integer yearOfProduction;
    @Column
    private Double volume;
    @Column
    private String description;
    @Column
    private String recommendations;
    @Column
    private String picture;
    @Column(name = "category")
    private Integer categoryID;

    public Product() {
    }

    public Product(String name, String brand, double price, int stock, String wineType, String countryOfOrigin, int yearOfProduction, double volume, String description, String recommendations, String categoryID) {
        this.name = name;
        this.brand = brand;
        this.price = price;
        this.stock = stock;
        this.medType = medType;
        this.countryOfOrigin = countryOfOrigin;
        this.yearOfProduction = yearOfProduction;
        this.volume = volume;
        this.description = description;
        this.recommendations = recommendations;
    }

    public int getWineId() {
        return medId;
    }

    public void setWineId(int wineId) {
        this.medId = wineId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public String getmedType() {
        return medType;
    }

    public void setmedType(String wineType) {
        this.medType = wineType;
    }

    public String getCountryOfOrigin() {
        return countryOfOrigin;
    }

    public void setCountryOfOrigin(String countryOfOrigin) {
        this.countryOfOrigin = countryOfOrigin;
    }

    public Integer getYearOfProduction() {
        return yearOfProduction;
    }

    public void setYearOfProduction(Integer yearOfProduction) {
        this.yearOfProduction = yearOfProduction;
    }

    public Double getVolume() {
        return volume;
    }

    public void setVolume(Double volume) {
        this.volume = volume;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRecommendations() {
        return recommendations;
    }

    public void setRecommendations(String recommendations) {
        this.recommendations = recommendations;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public Integer getCategoryID() {
        return categoryID;
    }

    public void setCategoryID(Integer categoryID) {
        this.categoryID = categoryID;
    }

    @Override
    public String toString() {
        return "Product{" +
                "wineId=" + medId +
                ", name='" + name + '\'' +
                ", brand='" + brand + '\'' +
                ", price=" + price +
                ", stock=" + stock +
                ", wineType='" + medType + '\'' +
                ", countryOfOrigin='" + countryOfOrigin + '\'' +
                ", yearOfProduction=" + yearOfProduction +
                ", volume=" + volume +
                ", description='" + description + '\'' +
                ", recommendations='" + recommendations + '\'' +
                '}';
    }
}