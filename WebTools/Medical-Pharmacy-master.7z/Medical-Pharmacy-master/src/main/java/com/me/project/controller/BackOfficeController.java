package com.me.project.controller;

import com.me.project.model.Category;
import com.me.project.model.Product;
import com.me.project.model.ProductDTO;
import com.me.project.model.users.UserDto;
import com.me.project.model.users.UserFormValidator;
import com.me.project.service.CategoriesService;
import com.me.project.service.FileSystemStorageService;
import com.me.project.service.ProductService;
import com.me.project.service.UserService;
import com.me.project.service.convertors.DTOConverter;
import com.me.project.service.validators.ProductValidator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

@Controller
public class BackOfficeController extends UserController {

    private static final Logger logger = LoggerFactory.getLogger(BackOfficeController.class);
    @Autowired
    private ProductService product_Service;
    @Autowired
    private UserService userService;
    @Autowired
    private CategoriesService categoriesService;
    @Autowired
    private FileSystemStorageService fileStorage;
    @Autowired
    private ProductValidator productValidator;
    @Autowired
    private DTOConverter converter;
    @Autowired
    private UserFormValidator userFormValidator;

    @InitBinder(value = "productDTO")
    private void initBinder(WebDataBinder binder) {
        binder.setValidator(productValidator);
    }


    @RequestMapping(value = "/home", method = RequestMethod.GET)
    public String home(Locale locale, Model model) {
        logger.info("Home page. The client locale is {}", locale);
        String authenticatedUserName = userService.getAuthenticatedUser().getName();
        model.addAttribute("userName", authenticatedUserName);
        return "home";
    }

    @RequestMapping(value = "/addProduct", method = RequestMethod.GET)
    public String showAddView(Locale locale, Model model) {
        List<Category> categories = categoriesService.getAllTheCategories();
        model.addAttribute("categories", categories);
        logger.info("Add product. The client locale is {}", locale);
        model.addAttribute("productDTO", new ProductDTO());

        String authenticatedUserName = userService.getAuthenticatedUser().getName();
        model.addAttribute("userName", authenticatedUserName);

        return "add-product";
    }

    @RequestMapping(value = "/addProduct", method = RequestMethod.POST)
    public String addProduct(Locale locale, Model model,
                             @ModelAttribute("productDTO") @Validated ProductDTO productDTO,
                             BindingResult bindingResult,
                             @RequestParam String category
                             //@RequestParam(value = "picture", required = false) MultipartFile file
    ) {
        if (bindingResult.hasErrors()) {
            logger.info("Input validation failed!");
            List<Category> categories = categoriesService.getAllTheCategories();
            model.addAttribute("categories", categories);

            String authenticatedUserName = userService.getAuthenticatedUser().getName();
            model.addAttribute("userName", authenticatedUserName);

            return "add-product";
        } else {
            List<Category> categories = categoriesService.getAllTheCategories();
            for (Category c : categories) {
                if (c.getName().equals(category))
                    productDTO.setCategoryID(c.getID());
            }
            Product product = converter.convertDTOToProduct(productDTO);
            boolean wasAdded = true;
            product_Service.addProduct(product);
            logger.info("Product added. The client locale is {}", locale);

            return "redirect:medicines";
        }
    }

    @RequestMapping(value = "/medicines", method = RequestMethod.GET)
    public String getProducts(Locale locale, Model model,HttpServletRequest request) {
        logger.info("List of wines. The client locale is {}", locale);
        model.addAttribute("wineList", product_Service.getAllProducts());
        String authenticatedUserName = userService.getAuthenticatedUser().getName();

        model.addAttribute("userName", authenticatedUserName);
        return "medicines";
    }

    @RequestMapping(value = "/importProducts", method = RequestMethod.POST)
    public String importProducts(@RequestParam("file") MultipartFile file, Model model) {
        int nb = 0;
        try {
            ByteArrayInputStream stream = new ByteArrayInputStream(file.getBytes());
            String myString = org.apache.commons.io.IOUtils.toString(stream, "UTF-8");
            nb = product_Service.manageImports(myString);
        } catch (IOException e) {
            logger.error("GET BYTES ERROR", e);
        }
        model.addAttribute("nbOfProducts", nb);
        return "import-message";
    }

 
    @RequestMapping(value = "/medi-edit", method = RequestMethod.POST)
    public String productHome(@ModelAttribute("productDTO") @Validated ProductDTO productDTO,
                              BindingResult bindingResult,
                              Model model,
                              @RequestParam(value = "picture", required = false) MultipartFile file) {
        if (bindingResult.hasErrors()) {
            logger.info("Input validation failed!");
            return "wine-edit";
        } else {
            Product product = converter.convertDTOToProduct(productDTO);
            product_Service.updateProduct(product);
            logger.info("You edit the dates successfully!");
            return "redirect:medicines";
        }
    }
    
    @RequestMapping(value = "/medi-edit/{id}", method = RequestMethod.GET)
    public String productEdit(Model model, @PathVariable Integer id) {
        logger.info("You are finally in edit mode!");
        ProductDTO productDTO = converter.convertProductToDTO(product_Service.getProduct(id));
        model.addAttribute("productDTO", productDTO);

        List<Category>categories = categoriesService.getAllTheCategories();
        model.addAttribute("categories", categories);

        return "wine-edit";
    }


    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public String deleteProduct(@RequestParam("deleteId") String id) {
        logger.info(id);
        product_Service.deleteProduct(id);
        return "redirect:medicines";
    }

    @RequestMapping(value = "/categories", method = RequestMethod.GET)
    public String categories(Model model){
        HashMap<String, Integer> categoryQuantityMap = categoriesService.getAllTheCategoriesMap();
        model.addAttribute("Categories", categoryQuantityMap);

        String authenticatedUserName = userService.getAuthenticatedUser().getName();
        model.addAttribute("userName", authenticatedUserName);
        return "categories";
    }

    @RequestMapping(value = "/categories", method = RequestMethod.POST)
    public String categories(Model model, @RequestParam String categoryName) {
        HashMap<String, Integer> categoryQuantityMap;
        Category category = new Category();

        category.setName(categoryName);

        if (categoriesService.addCategory(category))
            model.addAttribute("success", Boolean.TRUE);
        else
            model.addAttribute("success", Boolean.FALSE);

        categoryQuantityMap = categoriesService.getAllTheCategoriesMap();
        model.addAttribute("Categories", categoryQuantityMap);

        String authenticatedUserName = userService.getAuthenticatedUser().getName();
        model.addAttribute("userName", authenticatedUserName);
        return "categories";
    }

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login() {
        return "login-form";
    }


    @RequestMapping(value = "/deleteAll", method = RequestMethod.POST)
    public String deleteAll(@RequestParam(value = "getAll", defaultValue = "null") String id) {
        if (!"null".equals(id)) {
            product_Service.deleteAll(id);
        }
        return "redirect:medicines";
    }

    @RequestMapping(value = "/exportAllSuccess", method = RequestMethod.GET)
    @ResponseBody
    public FileSystemResource exportProductsSuccess(HttpServletRequest request) throws URISyntaxException {
        String ids=(String)request.getSession().getAttribute("ids");
        HttpServletResponse response=(HttpServletResponse) request.getSession().getAttribute("response");
        File file=product_Service.exportProducts(ids);
        response.setContentLength((int)file.getName().length());
        response.setContentType("application/force-download");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"");
        return new FileSystemResource(file);
    }
    
    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String register(Model model) {
        logger.info("You arrived into the register formular");
        UserDto userDto = new UserDto();
        model.addAttribute("user", userDto);

        return "registration";
    }
    
    @RequestMapping(value = "/exportAll", method = RequestMethod.POST )
    public String exportProducts(@RequestParam(value = "getAll",defaultValue = "null") String ids, HttpServletRequest request,
                                 HttpServletResponse response ) {
        if (ids.equals("null")){
            return "redirect:medicines";
        }
        else{
            request.getSession().setAttribute("ids",ids);
            request.getSession().setAttribute("response",response);
            return "redirect:exportAllSuccess";
        }
    }


    
    @RequestMapping(value="/register/{id}", method = RequestMethod.GET)
    public String userRegister(Model model, @PathVariable Integer id){

        logger.info("You can now confirm your registration");
        userService.activatingUserAccount(id);
        model.addAttribute("success",Boolean.TRUE);

        return "redirect:/login";
    }
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String registerUserAccount(Model model, @ModelAttribute("user") UserDto userDto, BindingResult bindingResult) {

        logger.info("Now it's time for registration validation");

        userFormValidator.validate(userDto, bindingResult);
        if (!bindingResult.hasErrors()) {
            userService.registerNewUserAccount(userDto);
            return "redirect:medicines";
        } else {
            model.addAttribute("user", userDto);
            return "registration";
        }
    }

 

}
