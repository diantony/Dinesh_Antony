package com.me.project.model;

public enum MedicineType {
    PAINKILLERS("painkillers"), ANALGESIC("analgesic"), ANTACID("antacid"), OTHERS("others");

    private String medTypeValue;

    MedicineType(String value) {
        this.medTypeValue = value;
    }

    public String getWineTypeValue() {
        return this.medTypeValue;
    }
}