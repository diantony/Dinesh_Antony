package com.me.project.interfaces;


import java.util.HashMap;
import java.util.List;

import com.me.project.model.Category;

public interface CategoriesManagerInterface{

    List<Category> getAllTheCategories();
    HashMap<String, Integer> getAllTheCategoriesMap();
    //Integer getTheNumberOfProducts(Category category);
    String getCategory(String productName);
    Boolean addCategory(Category category);

}