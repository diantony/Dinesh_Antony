package com.me.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.me.project.facade.CartFacade;

import javax.servlet.http.HttpSession;

public class UserController {

    protected static final String CART_SESSION_ATTRIBUTE_NAME = "sessionCartId";

    @Autowired
    CartFacade cartFacade;

    @ModelAttribute("nrProductsFromCart")
    @Transactional
    public Integer getNrProductsFromCart(HttpSession session) {
        Integer cartId = (Integer) session.getAttribute(CART_SESSION_ATTRIBUTE_NAME);
        Integer nrProductsFromCart = cartFacade.getNrProductsFromCart(cartId);

        return nrProductsFromCart;
    }
}
